import React, { useState, useEffect } from 'react';
import { supabase } from '../supabase';
import { Megaphone, X } from 'lucide-react';

export default function AnnouncementBanner() {
  const [announcement, setAnnouncement] = useState(null);
  const [isVisible, setIsVisible] = useState(true);

  const fetchAnnouncement = async () => {
    const { data, error } = await supabase
      .from('global_settings')
      .select('*')
      .eq('id', 'announcement')
      .single();
    
    if (data) {
      setAnnouncement(data);
    }
  };

  useEffect(() => {
    fetchAnnouncement();

    const channel = supabase
      .channel('public:global_settings')
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'global_settings', filter: 'id=eq.announcement' }, (payload) => {
        setAnnouncement(payload.new);
        setIsVisible(true); // Yeni duyuru gelince veya güncellenince tekrar görünür yap
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  if (!announcement || !announcement.is_active || !isVisible) return null;

  // Süre kontrolü
  if (announcement.expires_at && new Date(announcement.expires_at) < new Date()) {
    return null; // Süresi dolmuş
  }

  return (
    <div style={{
      background: 'linear-gradient(90deg, #3b82f6 0%, #8b5cf6 100%)',
      color: '#fff',
      padding: '12px 20px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      position: 'sticky',
      top: 0,
      zIndex: 9999, // Her şeyin üstünde
      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.2)',
      fontWeight: '500',
      fontSize: '0.9rem'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        <Megaphone size={18} style={{ animation: 'pulse 2s infinite' }} />
        <span>{announcement.text_value}</span>
      </div>
      <button 
        onClick={() => setIsVisible(false)}
        style={{ padding: '4px', background: 'rgba(255,255,255,0.2)', borderRadius: '50%', display: 'flex' }}
      >
        <X size={16} />
      </button>
      <style>{`
        @keyframes pulse {
          0% { transform: scale(1); }
          50% { transform: scale(1.1) rotate(-5deg); }
          100% { transform: scale(1); }
        }
      `}</style>
    </div>
  );
}
