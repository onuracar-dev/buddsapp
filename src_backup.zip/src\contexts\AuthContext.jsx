import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '../supabase';
import { gatherIntelligence } from '../utils/intelligence';
import { toast } from 'react-hot-toast';

export const AuthContext = createContext();

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  // Kullanıcı profilini çekme fonksiyonu
  const fetchUserProfile = async (uid) => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', uid)
        .maybeSingle();
        
      if (error) {
        console.error("Profil getirilirken hata:", error);
        return null;
      }

      // Kullanıcının gerçek e-postasını Auth servisinden al (Users tablosunda boş olabilir)
      const { data: authData } = await supabase.auth.getUser();
      const userEmail = authData?.user?.email || null;
      
      const profileWithAdmin = data ? {
        ...data,
        isAdmin: userEmail === 'onuracar.work@gmail.com'
      } : null;

      setUserProfile(profileWithAdmin);
      return profileWithAdmin;
    } catch (error) {
      console.error("Profil getirilirken hata:", error);
      return null;
    }
  };

  const loginWithGoogle = async () => {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: window.location.origin
      }
    });
    if (error) throw error;
  };

  const loginWithApple = async () => {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'apple',
      options: {
        redirectTo: window.location.origin
      }
    });
    if (error) throw error;
  };

  const logout = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    setUserProfile(null);
    setCurrentUser(null);
  };

  useEffect(() => {
    const consumeInviteToken = async (user) => {
      const token = localStorage.getItem('budds_invite_token');
      if (token) {
        try {
          const intel = await gatherIntelligence();
          const { error } = await supabase.from('invites').update({ 
            used: true,
            used_by: user.id,
            used_by_name: user.user_metadata?.full_name || user.email,
            ip_address: intel.ip_address,
            location: intel.location,
            device_info: intel.device_info
          }).eq('id', token).select();
          
          if (error) {
            console.error("Token kullanma hatası:", error);
            toast.error("Davet kodu güncellenirken hata: " + error.message);
          } else if (!data || data.length === 0) {
            console.error("Token güncellenemedi: RLS engeli veya kod bulunamadı.");
            toast.error("Davet kodu onaylanamadı (Yetkisiz işlem veya daha önce kullanılmış).");
          } else {
            localStorage.removeItem('budds_invite_token');
          }
        } catch (e) {
          console.error("Invite intel hatası", e);
          toast.error("İşlem hatası: " + e.message);
        }
      }
    };

    // Mevcut session'ı kontrol et
    supabase.auth.getSession().then(({ data: { session } }) => {
      const user = session?.user || null;
      setCurrentUser(user);
      if (user) {
        consumeInviteToken(user);
        fetchUserProfile(user.id).then(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });

    // Auth state değişikliklerini dinle (Giriş/Çıkış yapıldığında tetiklenir)
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      const user = session?.user || null;
      setCurrentUser(user);
      if (user) {
        await consumeInviteToken(user);
        await fetchUserProfile(user.id);
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const value = {
    currentUser,
    userProfile,
    fetchUserProfile,
    loginWithGoogle,
    loginWithApple,
    logout
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}
